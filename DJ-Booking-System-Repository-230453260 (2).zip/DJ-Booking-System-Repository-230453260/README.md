# Rands-Cape-Town-Database-Application
ADP3 Project 

This was completed through each member working with all classes of their respective entities.
Collaboration/compilation of projects done by Leslie

Maphelo-     Dj, Equipment, Admin
Alvaro-      Timeslot, Genre
Indiphile-   Song, Payment          
Leslie-      Review, Date
Boitumelo-   Gig, Booking

Java

