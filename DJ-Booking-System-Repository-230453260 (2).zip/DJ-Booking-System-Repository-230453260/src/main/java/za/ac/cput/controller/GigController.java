package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.Gig;
import za.ac.cput.service.IGigService;

import java.util.List;

@RestController
@RequestMapping("/api/gig")
public class GigController {

    private final IGigService gigService;

    @Autowired
    public GigController(IGigService gigService) {
        this.gigService = gigService;
    }

    // Admin can manually create gig (normally auto-created when booking approved)
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create")
    public ResponseEntity<Gig> create(@RequestBody Gig gig) {
        Gig createdGig = gigService.create(gig);
        return new ResponseEntity<>(createdGig, HttpStatus.CREATED);
    }

    // Admin can read gig details
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/read/{id}")
    public ResponseEntity<Gig> read(@PathVariable Long id) {
        Gig gig = gigService.read(id);
        if (gig != null) {
            return new ResponseEntity<>(gig, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Admin can update gig details
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/update")
    public ResponseEntity<Gig> update(@RequestBody Gig gig) {
        Gig updatedGig = gigService.update(gig);
        if (updatedGig != null) {
            return new ResponseEntity<>(updatedGig, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Admin can delete gig
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean deleted = gigService.delete(id);
        if (deleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Admin can view all gigs
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<Gig>> getAll() {
        List<Gig> gigs = gigService.getAll();
        return new ResponseEntity<>(gigs, HttpStatus.OK);
    }
}