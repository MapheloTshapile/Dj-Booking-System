package za.ac.cput.domain;

public enum BookingStatus {
    PENDING,
    APPROVED,
    DECLINED,
    ON_HOLD,
    COMPLETED
}
