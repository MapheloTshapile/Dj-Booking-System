package za.ac.cput.service;

// IAdminService removed intentionally. Use IUserService for user operations.

