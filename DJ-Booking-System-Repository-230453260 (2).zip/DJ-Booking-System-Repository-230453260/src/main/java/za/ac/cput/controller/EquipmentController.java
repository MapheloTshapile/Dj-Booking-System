package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.Equipment;
import za.ac.cput.service.IEquipmentService;

import java.util.List;

@RestController
@RequestMapping("/api/equipment")
public class EquipmentController {

    private final IEquipmentService equipmentService;

    @Autowired
    public EquipmentController(IEquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @PostMapping("/create")
    public ResponseEntity<Equipment> create(@RequestBody Equipment equipment) {
        Equipment createdEquipment = equipmentService.create(equipment);
        return new ResponseEntity<>(createdEquipment, HttpStatus.CREATED);
    }

    @GetMapping("/read/{id}")
    public ResponseEntity<Equipment> read(@PathVariable Long id) {
        Equipment equipment = equipmentService.read(id);
        if (equipment != null) {
            return new ResponseEntity<>(equipment, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/update")
    public ResponseEntity<Equipment> update(@RequestBody Equipment equipment) {
        Equipment updatedEquipment = equipmentService.update(equipment);
        if (updatedEquipment != null) {
            return new ResponseEntity<>(updatedEquipment, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean deleted = equipmentService.delete(id);
        if (deleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Equipment>> getAll() {
        List<Equipment> equipmentList = equipmentService.getAll();
        return new ResponseEntity<>(equipmentList, HttpStatus.OK);
    }
}