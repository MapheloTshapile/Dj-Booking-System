package za.ac.cput.factory;

import za.ac.cput.domain.Booking;
import za.ac.cput.domain.Payment;
import za.ac.cput.domain.PaymentMethod;
import za.ac.cput.domain.PaymentStatus;
import za.ac.cput.utilities.Helper;

import java.time.LocalDateTime;

public class PaymentFactory {
    public static Payment createPayment(Long paymentId, double amount, LocalDateTime paymentDate, String paymentMethod, Booking booking) {

        //  Validate inputs for the Payment object
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be a positive value.");
        }
        if (paymentDate == null) {
            throw new IllegalArgumentException("Payment date cannot be null.");
        }

        // Use the helper to validate the payment method string if provided
        if (Helper.isNullOrEmpty(paymentMethod)) {
            throw new IllegalArgumentException("Payment method cannot be null or empty");
        }

        PaymentMethod methodEnum;
        try {
            methodEnum = PaymentMethod.valueOf(paymentMethod.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unsupported payment method: " + paymentMethod);
        }

        if (booking == null) {
            throw new IllegalArgumentException("Booking cannot be null.");
        }

        // Default status is PENDING when a payment is first created
        PaymentStatus initialStatus = PaymentStatus.PENDING;

        // 🛠️ Use the Builder to construct the Payment object
        return new Payment.Builder()
                .setPaymentId(paymentId)
                .setAmount(amount)
                .setPaymentDate(paymentDate)
                .setPaymentMethod(methodEnum)
                .setStatus(initialStatus)
                .setBooking(booking)
                .build();
    }
}
