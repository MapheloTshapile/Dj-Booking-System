package za.ac.cput.factory;

import za.ac.cput.domain.AvailabilityStatus;
import za.ac.cput.domain.Booking;
import za.ac.cput.domain.DJ;
import za.ac.cput.domain.Payment;
import za.ac.cput.utilities.Helper;

import java.time.LocalDate;
import java.time.LocalTime;

public class BookingFactory {
    public static Booking createBooking(Long bookingId, za.ac.cput.domain.User user, DJ dj, LocalDate bookingDate,
                                        LocalTime startTime, LocalTime endTime, String location, Payment payment) {

        // 📝 Validate all required inputs
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }
        if (dj == null) {
            throw new IllegalArgumentException("DJ cannot be null.");
        }
        if (bookingDate == null) {
            throw new IllegalArgumentException("Booking date cannot be null.");
        }
        if (startTime == null) {
            throw new IllegalArgumentException("Start time cannot be null.");
        }
        if (endTime == null) {
            throw new IllegalArgumentException("End time cannot be null.");
        }
        if (Helper.isNullOrEmpty(location)) {
            throw new IllegalArgumentException("Location cannot be null or empty.");
        }

        // Ensure start time is before end time for a valid booking duration
        if (startTime.isAfter(endTime)) {
            throw new IllegalArgumentException("Start time cannot be after end time.");
        }

        // Ensure DJ is available
        if (dj.getAvailabilityStatus() == AvailabilityStatus.UNAVAILABLE) {
            throw new IllegalArgumentException("Cannot book a DJ who is currently unavailable.");
        }

        // 🛠️ Use the Builder pattern to construct the Booking object
    return new Booking.Builder()
        .setBookingId(bookingId)
        .setUser(user)
        .setDj(dj)
                .setEventDate(bookingDate)
                .setStartTime(startTime)
                .setEndTime(endTime)
                .setVenue(location.trim())
                .setPayment(payment) // Payment can be null initially, so no explicit check is needed
                .build();
    }
}
