package za.ac.cput.domain;

public enum Role {
    ADMIN,
    EVENT_ORGANIZER
}
