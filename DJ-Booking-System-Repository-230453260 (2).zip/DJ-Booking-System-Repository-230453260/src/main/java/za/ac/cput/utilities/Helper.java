package za.ac.cput.utilities;
import org.apache.commons.validator.routines.EmailValidator;
import java.util.UUID;

/**
 * Utility validation and helper methods for DJ Booking System.
 */
public class Helper {

    private Helper() {} // prevent instantiation

    // 🔹 Generic Null/Empty validation
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    // 🔹 ID Generator (for external IDs if needed, e.g. booking ref)
    public static String generateId(String prefix) {
        return prefix + "-" + UUID.randomUUID().toString().substring(0, 8);
    }

    // 🔹 Name validation
    public static String validateName(String name) {
        if (isNullOrEmpty(name)) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
        if (!name.matches("^[a-zA-Z ]+$")) {
            throw new IllegalArgumentException("Name must only contain letters and spaces");
        }
        return name.trim();
    }

    // 🔹 Email validation
    public static String validateEmail(String email) {
        if (isNullOrEmpty(email)) {
            throw new IllegalArgumentException("Email cannot be null or empty");
        }
        EmailValidator validator = EmailValidator.getInstance();
        if (!validator.isValid(email)) {
            throw new IllegalArgumentException("Invalid email format: " + email);
        }
        return email.trim().toLowerCase();
    }

    // 🔹 Contact number validation (South Africa format: 10 digits starting with 0)
    public static String validateContactNumber(String number) {
        if (isNullOrEmpty(number)) {
            throw new IllegalArgumentException("Contact number cannot be null or empty");
        }
        String digits = number.replaceAll("[^0-9]", "");
        if (!digits.matches("^0\\d{9}$")) {
            throw new IllegalArgumentException("Contact number must be 10 digits starting with 0");
        }
        return digits;
    }

    // 🔹 Password validation
    public static String validatePassword(String password) {
        if (isNullOrEmpty(password)) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        if (password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long");
        }
        return password;
    }

    // 🔹 Payment method validation
    public static String validatePaymentMethod(String method) {
        if (isNullOrEmpty(method)) {
            throw new IllegalArgumentException("Payment method cannot be empty");
        }
        String normalized = method.trim().toLowerCase();
        switch (normalized) {
            case "cash":
            case "card":
            case "eft":
                return normalized;
            default:
                throw new IllegalArgumentException("Unsupported payment method: " + method);
        }
    }

    // 🔹 Rating validation
    public static int validateRating(int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }
        return rating;
    }
}