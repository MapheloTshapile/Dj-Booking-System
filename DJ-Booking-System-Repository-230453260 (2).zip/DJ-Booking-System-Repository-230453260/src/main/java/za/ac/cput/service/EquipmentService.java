package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Equipment;
import za.ac.cput.repository.EquipmentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EquipmentService implements IEquipmentService {

    private final EquipmentRepository repository;

    @Autowired
    public EquipmentService(EquipmentRepository repository) {
        this.repository = repository;
    }

    @Override
    public Equipment create(Equipment equipment) {
        return repository.save(equipment);
    }

    @Override
    public Equipment read(Long equipmentId) {
        Optional<Equipment> optionalEquipment = repository.findById(equipmentId);
        return optionalEquipment.orElse(null);
    }

    @Override
    public Equipment update(Equipment equipment) {
        if (repository.existsById(equipment.getEquipmentId())) {
            return repository.save(equipment);
        }
        return null;
    }

    @Override
    public boolean delete(Long equipmentId) {
        if (repository.existsById(equipmentId)) {
            repository.deleteById(equipmentId);
            return true;
        }
        return false;
    }

    @Override
    public List<Equipment> getAll() {
        return repository.findAll();
    }
}
