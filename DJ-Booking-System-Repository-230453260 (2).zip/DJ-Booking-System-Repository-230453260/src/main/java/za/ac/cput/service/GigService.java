package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Gig;
import za.ac.cput.repository.GigRepository;

import java.util.List;
import java.util.Optional;

@Service
public class GigService implements IGigService {

    private final GigRepository repository;

    @Autowired
    public GigService(GigRepository repository) {
        this.repository = repository;
    }

    @Override
    public Gig create(Gig gig) {
        return repository.save(gig);
    }

    @Override
    public Gig read(Long gigId) {
        Optional<Gig> optionalGig = repository.findById(gigId);
        return optionalGig.orElse(null);
    }

    @Override
    public Gig update(Gig gig) {
        if (repository.existsById(gig.getGigId())) {
            return repository.save(gig);
        }
        return null;
    }

    @Override
    public boolean delete(Long gigId) {
        if (repository.existsById(gigId)) {
            repository.deleteById(gigId);
            return true;
        }
        return false;
    }

    @Override
    public List<Gig> getAll() {
        return repository.findAll();
    }
}