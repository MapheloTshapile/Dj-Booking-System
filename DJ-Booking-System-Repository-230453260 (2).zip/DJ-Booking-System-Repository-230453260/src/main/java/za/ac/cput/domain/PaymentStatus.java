package za.ac.cput.domain;

public enum PaymentStatus {
    PENDING,
    APPROVED,
    PAID,
    COMPLETED,
    CANCELED
}
