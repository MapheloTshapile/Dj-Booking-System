package za.ac.cput.factory;

import za.ac.cput.domain.DJ;
import za.ac.cput.domain.Review;
import za.ac.cput.utilities.Helper;

import java.time.LocalDateTime;

public class ReviewFactory {
    public static Review createReview(Long reviewId, za.ac.cput.domain.User user, DJ dj, int rating, String comment) {

        //  Validate inputs for the Review object
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }
        if (dj == null) {
            throw new IllegalArgumentException("DJ cannot be null.");
        }

        // Use the helper to validate the rating (1-5 stars)
        int validatedRating = Helper.validateRating(rating);

        // Require a non-empty comment per your request
        if (Helper.isNullOrEmpty(comment)) {
            throw new IllegalArgumentException("Comment cannot be null or empty");
        }

        String validatedComment = comment.trim();

        // Default review date to now
        LocalDateTime reviewDate = LocalDateTime.now();

        //  Use the Builder to construct the Review object
        return new Review.Builder()
                .setReviewId(reviewId)
                .setUser(user)
                .setDj(dj)
                .setRating(validatedRating)
                .setComment(validatedComment)
                .setReviewDate(reviewDate)
                .build();
    }
}
