package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import za.ac.cput.domain.Payment;
import za.ac.cput.domain.Booking;
import za.ac.cput.domain.BookingStatus;
import za.ac.cput.domain.PaymentStatus;
import za.ac.cput.repository.PaymentRepository;
import za.ac.cput.repository.BookingRepository;

import java.util.List;
import java.util.Optional;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class PaymentService implements IPaymentService {

    private final PaymentRepository repository;
    private final BookingRepository bookingRepository;
    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);

    @PersistenceContext
    private EntityManager em;

    @Autowired
    public PaymentService(PaymentRepository repository, BookingRepository bookingRepository) {
        this.repository = repository;
        this.bookingRepository = bookingRepository;
    }

    @Override
    public Payment create(Payment payment) {
        // ✅ Just save - the Builder already handles bookingId population
        Payment saved = repository.save(payment);
        logger.info("Created payment with id {} for booking {} with status {}",
                saved.getPaymentId(), saved.getBookingId(), saved.getStatus());
        return saved;
    }

    @Override
    public Payment read(Long paymentId) {
        Optional<Payment> optionalPayment = repository.findById(paymentId);
        return optionalPayment.orElse(null);
    }

    @Override
    public Payment update(Payment payment) {
        if (!repository.existsById(payment.getPaymentId())) {
            logger.warn("Payment {} not found for update", payment.getPaymentId());
            return null;
        }

        // Read existing payment to check status transition
        Payment existing = repository.findById(payment.getPaymentId()).orElse(null);
        if (existing == null) return null;

        Payment saved = repository.save(payment);
        logger.info("Updated payment {} from status {} to {} for booking {}",
                saved.getPaymentId(), existing.getStatus(), saved.getStatus(), saved.getBookingId());

        // ✅ Mark booking as COMPLETED only when payment status reaches COMPLETED
        if (existing.getStatus() != saved.getStatus() && saved.getStatus() == PaymentStatus.COMPLETED) {
            Booking booking = saved.getBooking();
            if (booking != null) {
                logger.info("Payment {} marked as COMPLETED, updating booking {} status to COMPLETED",
                        saved.getPaymentId(), booking.getBookingId());
                booking.setStatus(BookingStatus.COMPLETED);
                bookingRepository.save(booking);
            } else {
                logger.warn("Payment {} marked as COMPLETED but has no associated booking!", saved.getPaymentId());
            }
        }

        return saved;
    }

    @Override
    @Transactional
    public boolean delete(Long paymentId) {
        Optional<Payment> opt = repository.findById(paymentId);
        if (opt.isPresent()) {
            Payment payment = opt.get();
            repository.delete(payment);
            try {
                repository.flush();
            } catch (Exception e) {
                logger.warn("Flush after delete failed: {}", e.getMessage());
            }
            logger.info("Deleted payment with id {}", paymentId);
            return true;
        }
        logger.info("Payment id {} not found for deletion", paymentId);
        return false;
    }

    @Override
    @Transactional
    public boolean forceDelete(Long id) {
        Optional<Payment> opt = repository.findById(id);
        if (opt.isPresent()) {
            Payment p = opt.get();
            try {
                if (!em.contains(p)) {
                    p = em.merge(p);
                }
                em.remove(p);
                em.flush();
            } catch (Exception e) {
                logger.warn("Force delete failed for payment {}: {}", id, e.getMessage());
                return false;
            }

            try {
                em.getEntityManagerFactory().getCache().evict(Payment.class, id);
            } catch (Exception e) {
                logger.debug("Cache eviction skipped or failed: {}", e.getMessage());
            }

            logger.info("Force-deleted payment id {}", id);
            return true;
        }
        logger.info("Payment id {} not found for force-delete", id);
        return false;
    }

    @Override
    public List<Payment> getAll() {
        return repository.findAll();
    }
}