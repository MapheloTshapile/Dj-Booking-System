package za.ac.cput.domain;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    private double amount;
    private LocalDateTime paymentDate;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;

    // ✅ WRITABLE bookingId field - JPA can write to this
    @Column(name = "booking_id")
    private Long bookingId;

    // ✅ Booking relationship is now IGNORED by JPA for persistence
    @OneToOne
    @JoinColumn(name = "booking_id", insertable = false, updatable = false)
    @JsonIgnore
    private Booking booking;

    protected Payment() {}

    private Payment(Builder builder) {
        this.paymentId = builder.paymentId;
        this.amount = builder.amount;
        this.paymentDate = builder.paymentDate;
        this.paymentMethod = builder.paymentMethod;
        this.status = builder.status;
        this.bookingId = builder.bookingId;
        this.booking = builder.booking;
    }

    public Long getPaymentId() { return paymentId; }
    public double getAmount() { return amount; }
    public LocalDateTime getPaymentDate() { return paymentDate; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public PaymentStatus getStatus() { return status; }
    public Long getBookingId() { return bookingId; }
    public Booking getBooking() { return booking; }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "paymentId=" + paymentId +
                ", amount=" + amount +
                ", paymentDate=" + paymentDate +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", bookingId=" + bookingId +
                ", status=" + status +
                '}';
    }

    public static class Builder {
        private Long paymentId;
        private double amount;
        private LocalDateTime paymentDate;
        private PaymentMethod paymentMethod;
        private PaymentStatus status;
        private Long bookingId;
        private Booking booking;

        public Builder setPaymentId(Long paymentId) { this.paymentId = paymentId; return this; }
        public Builder setAmount(double amount) { this.amount = amount; return this; }
        public Builder setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; return this; }
        public Builder setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; return this; }
        public Builder setStatus(PaymentStatus status) { this.status = status; return this; }

        public Builder setBookingId(Long bookingId) {
            this.bookingId = bookingId;
            return this;
        }

        public Builder setBooking(Booking booking) {
            this.booking = booking;
            if (booking != null) {
                this.bookingId = booking.getBookingId();
            }
            return this;
        }

        public Builder copy(Payment p) {
            this.paymentId = p.paymentId;
            this.amount = p.amount;
            this.paymentDate = p.paymentDate;
            this.paymentMethod = p.paymentMethod;
            this.status = p.status;
            this.bookingId = p.bookingId;
            this.booking = p.booking;
            return this;
        }

        public Payment build() { return new Payment(this); }
    }
}