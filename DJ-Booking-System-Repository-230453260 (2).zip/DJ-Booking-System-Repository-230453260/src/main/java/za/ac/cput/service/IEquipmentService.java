package za.ac.cput.service;

import za.ac.cput.domain.Equipment;

import java.util.List;

public interface IEquipmentService extends IService<Equipment, Long> {
    List<Equipment> getAll();
}
