package za.ac.cput.domain;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

import java.math.BigDecimal;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "dj_id")
    private DJ dj;

    private LocalDate eventDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private String venue;
    
    @Enumerated(EnumType.STRING)
    private BookingStatus status;

    private BigDecimal totalAmount;

    @OneToOne(mappedBy = "booking", cascade = CascadeType.ALL)
    @JsonIgnore
    private Payment payment;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "gig_id")
    @JsonIgnore
    private Gig gig;

    protected Booking() {}

    private Booking(Builder builder) {
        this.bookingId = builder.bookingId;
        this.user = builder.user;
        this.dj = builder.dj;
        this.eventDate = builder.eventDate;
        this.startTime = builder.startTime;
        this.endTime = builder.endTime;
        this.venue = builder.venue;
        this.status = builder.status;
        this.totalAmount = builder.totalAmount;
        this.payment = builder.payment;
        this.gig = builder.gig;
    }

    public Long getBookingId() { return bookingId; }
    public User getUser() { return user; }
    public DJ getDj() { return dj; }
    public LocalDate getEventDate() { return eventDate; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public String getVenue() { return venue; }
    public Payment getPayment() { return payment; }
    public BookingStatus getStatus() { return status; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public Gig getGig() { return gig; }

    @Override
    public String toString() {
        return "Booking{" +
                "bookingId=" + bookingId +
                ", user=" + user +
                ", dj=" + dj +
                ", eventDate=" + eventDate +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", venue='" + venue + '\'' +
                ", payment=" + payment +
                ", status=" + status +
                ", totalAmount=" + totalAmount +
                ", gig=" + gig +
                '}';
    }

    // Mutators used by services when lifecycle changes
    public void setStatus(BookingStatus status) { this.status = status; }
    public void setGig(Gig gig) { this.gig = gig; }
    public void setTotalAmount(java.math.BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public static class Builder {
        private Long bookingId;
    private User user;
        private DJ dj;
    private LocalDate eventDate;
        private LocalTime startTime;
        private LocalTime endTime;
    private String venue;
    private BookingStatus status;
    private BigDecimal totalAmount;
        private Payment payment;
    private Gig gig;

        public Builder setBookingId(Long bookingId) { this.bookingId = bookingId; return this; }
    public Builder setUser(User user) { this.user = user; return this; }
        public Builder setDj(DJ dj) { this.dj = dj; return this; }
    public Builder setEventDate(LocalDate eventDate) { this.eventDate = eventDate; return this; }
        public Builder setStartTime(LocalTime startTime) { this.startTime = startTime; return this; }
        public Builder setEndTime(LocalTime endTime) { this.endTime = endTime; return this; }
    public Builder setVenue(String venue) { this.venue = venue; return this; }
    public Builder setStatus(BookingStatus status) { this.status = status; return this; }
    public Builder setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; return this; }
        public Builder setPayment(Payment payment) { this.payment = payment; return this; }
    public Builder setGig(Gig gig) { this.gig = gig; return this; }

        public Builder copy(Booking b) {
            this.bookingId = b.bookingId;
            this.user = b.user;
            this.dj = b.dj;
            this.eventDate = b.eventDate;
            this.startTime = b.startTime;
            this.endTime = b.endTime;
            this.venue = b.venue;
            this.status = b.status;
            this.totalAmount = b.totalAmount;
            this.payment = b.payment;
            this.gig = b.gig;
            return this;
        }

        public Booking build() { return new Booking(this); }
    }
}