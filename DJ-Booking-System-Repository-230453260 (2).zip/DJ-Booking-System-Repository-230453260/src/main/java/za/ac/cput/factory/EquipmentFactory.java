package za.ac.cput.factory;

import za.ac.cput.domain.Equipment;
import za.ac.cput.utilities.Helper;

public class EquipmentFactory {
    public static Equipment createEquipment(Long equipmentId, String equipmentName, String type) {

        // 📝 Validate inputs for the Equipment object
        if (Helper.isNullOrEmpty(equipmentName)) {
            throw new IllegalArgumentException("Equipment name cannot be null or empty.");
        }
        if (Helper.isNullOrEmpty(type)) {
            throw new IllegalArgumentException("Equipment type cannot be null or empty.");
        }

        // 🛠️ Use the Builder to construct the Equipment object
        return new Equipment.Builder()
                .setEquipmentId(equipmentId)
                .setEquipmentName(equipmentName.trim())
                .setType(type.trim())
                .build();
    }
}
