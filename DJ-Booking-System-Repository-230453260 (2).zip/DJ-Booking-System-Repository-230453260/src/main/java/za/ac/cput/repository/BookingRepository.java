package za.ac.cput.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import za.ac.cput.domain.Booking;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

	// Find bookings for a DJ on a specific date that overlap with a given time range
	List<Booking> findByDj_DjIdAndEventDateAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
			Long djId, LocalDate eventDate, LocalTime endTime, LocalTime startTime);
}