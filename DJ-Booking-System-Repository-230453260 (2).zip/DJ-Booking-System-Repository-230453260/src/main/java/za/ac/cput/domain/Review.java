package za.ac.cput.domain;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reviewId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "dj_id")
    private DJ dj;

    private int rating; // 1–5 stars
    private String comment;
    private LocalDateTime reviewDate;

    protected Review() {}

    private Review(Builder builder) {
        this.reviewId = builder.reviewId;
        this.user = builder.user;
        this.dj = builder.dj;
        this.rating = builder.rating;
        this.comment = builder.comment;
        this.reviewDate = builder.reviewDate;
    }

    public Long getReviewId() { return reviewId; }
    public User getUser() { return user; }
    public DJ getDj() { return dj; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }
    public LocalDateTime getReviewDate() { return reviewDate; }

    @Override
    public String toString() {
        return "Review{" +
                "reviewId=" + reviewId +
                ", user=" + user +
                ", dj=" + dj +
                ", rating=" + rating +
                ", comment='" + comment + '\'' +
                '}';
    }

    public static class Builder {
        private Long reviewId;
    private User user;
        private DJ dj;
        private int rating;
        private String comment;
    private LocalDateTime reviewDate;

        public Builder setReviewId(Long reviewId) { this.reviewId = reviewId; return this; }
    public Builder setUser(User user) { this.user = user; return this; }
        public Builder setDj(DJ dj) { this.dj = dj; return this; }
        public Builder setRating(int rating) { this.rating = rating; return this; }
        public Builder setComment(String comment) { this.comment = comment; return this; }
    public Builder setReviewDate(LocalDateTime reviewDate) { this.reviewDate = reviewDate; return this; }

        public Builder copy(Review r) {
            this.reviewId = r.reviewId;
            this.user = r.user;
            this.dj = r.dj;
            this.rating = r.rating;
            this.comment = r.comment;
            this.reviewDate = r.reviewDate;
            return this;
        }

        public Review build() { return new Review(this); }
    }
}