package za.ac.cput.domain;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "gigs")
public class Gig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long gigId;

    private String title;
    private String venue;
    private LocalDateTime eventDateTime;

    @ManyToOne
    @JoinColumn(name = "dj_id")
    private DJ dj;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    private LocalDateTime confirmedDate;
    private String location;

    protected Gig() {}

    private Gig(Builder builder) {
        this.gigId = builder.gigId;
        this.title = builder.title;
        this.venue = builder.venue;
        this.eventDateTime = builder.eventDateTime;
        this.dj = builder.dj;
        this.booking = builder.booking;
        this.confirmedDate = builder.confirmedDate;
        this.location = builder.location;
    }

    public Long getGigId() { return gigId; }
    public String getTitle() { return title; }
    public String getVenue() { return venue; }
    public LocalDateTime getEventDateTime() { return eventDateTime; }
    public DJ getDj() { return dj; }
    public Booking getBooking() { return booking; }
    public LocalDateTime getConfirmedDate() { return confirmedDate; }
    public String getLocation() { return location; }

    public static class Builder {
        private Long gigId;
        private String title;
        private String venue;
        private LocalDateTime eventDateTime;
        private DJ dj;
    private Booking booking;
    private LocalDateTime confirmedDate;
    private String location;

        public Builder setGigId(Long gigId) { this.gigId = gigId; return this; }
        public Builder setTitle(String title) { this.title = title; return this; }
        public Builder setVenue(String venue) { this.venue = venue; return this; }
        public Builder setEventDateTime(LocalDateTime eventDateTime) { this.eventDateTime = eventDateTime; return this; }
        public Builder setDj(DJ dj) { this.dj = dj; return this; }
    public Builder setBooking(Booking booking) { this.booking = booking; return this; }
    public Builder setConfirmedDate(LocalDateTime confirmedDate) { this.confirmedDate = confirmedDate; return this; }
    public Builder setLocation(String location) { this.location = location; return this; }

        public Builder copy(Gig g) {
            this.gigId = g.gigId;
            this.title = g.title;
            this.venue = g.venue;
            this.eventDateTime = g.eventDateTime;
            this.dj = g.dj;
            this.booking = g.booking;
            this.confirmedDate = g.confirmedDate;
            this.location = g.location;
            return this;
        }

        public Gig build() { return new Gig(this); }
    }
}