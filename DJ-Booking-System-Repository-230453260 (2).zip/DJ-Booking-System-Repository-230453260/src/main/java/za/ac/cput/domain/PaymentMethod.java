package za.ac.cput.domain;

public enum PaymentMethod {
    CASH,
    CARD,
    EFT
}
