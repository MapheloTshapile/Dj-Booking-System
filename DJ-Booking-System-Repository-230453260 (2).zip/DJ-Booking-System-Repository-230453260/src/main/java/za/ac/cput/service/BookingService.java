package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Booking;
import za.ac.cput.repository.BookingRepository;
import za.ac.cput.repository.GigRepository;
import za.ac.cput.domain.BookingStatus;
import za.ac.cput.domain.Gig;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService implements IBookingService {

    private final BookingRepository repository;
    private final GigRepository gigRepository;

    @Autowired
    public BookingService(BookingRepository repository, GigRepository gigRepository) {
        this.repository = repository;
        this.gigRepository = gigRepository;
    }

    @Override
    public Booking create(Booking booking) {
        // Validation: required fields
        if (booking.getDj() == null) throw new IllegalArgumentException("DJ is required");
        if (booking.getUser() == null) throw new IllegalArgumentException("User is required");
        if (booking.getEventDate() == null) throw new IllegalArgumentException("Event date is required");
        if (booking.getStartTime() == null || booking.getEndTime() == null) throw new IllegalArgumentException("Start and end times are required");
        if (booking.getVenue() == null || booking.getVenue().trim().isEmpty()) throw new IllegalArgumentException("Venue is required");

        // Check DJ availability
        if (booking.getDj().getAvailabilityStatus() != null && booking.getDj().getAvailabilityStatus().name().equals("UNAVAILABLE")) {
            throw new IllegalArgumentException("DJ is currently unavailable");
        }

        // Check overlapping bookings for DJ
        List<Booking> overlaps = repository.findByDj_DjIdAndEventDateAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                booking.getDj().getDjId(), booking.getEventDate(), booking.getEndTime(), booking.getStartTime());
        if (overlaps != null && !overlaps.isEmpty()) {
            throw new IllegalArgumentException("DJ already has a booking in the requested time range");
        }

        // Set initial status to PENDING
        if (booking.getStatus() == null) booking.setStatus(BookingStatus.PENDING);

        return repository.save(booking);
    }

    @Override
    public Booking read(Long bookingId) {
        Optional<Booking> optionalBooking = repository.findById(bookingId);
        return optionalBooking.orElse(null);
    }

    @Override
    public Booking update(Booking booking) {
        if (!repository.existsById(booking.getBookingId())) return null;

        Booking existing = repository.findById(booking.getBookingId()).orElse(null);
        if (existing == null) return null;

        // If status changes to APPROVED, create a Gig and link it
        if (existing.getStatus() != booking.getStatus() && booking.getStatus() == BookingStatus.APPROVED) {
            // create gig
        Gig gig = new Gig.Builder()
            .setTitle("Gig for booking " + booking.getBookingId())
            .setVenue(booking.getVenue())
            .setEventDateTime(LocalDateTime.of(booking.getEventDate(), booking.getStartTime()))
            .setDj(booking.getDj())
            .setBooking(booking)
            .setConfirmedDate(LocalDateTime.now())
            .setLocation(booking.getVenue())
            .build();
            Gig savedGig = gigRepository.save(gig);
            booking.setGig(savedGig);
        }

        return repository.save(booking);
    }

    @Override
    public boolean delete(Long bookingId) {
        if (repository.existsById(bookingId)) {
            repository.deleteById(bookingId);
            return true;
        }
        return false;
    }

    @Override
    public List<Booking> getAll() {
        return repository.findAll();
    }
}
