package za.ac.cput.factory;

import za.ac.cput.domain.DJ;
import za.ac.cput.domain.Gig;
import za.ac.cput.utilities.Helper;

import java.time.LocalDateTime;

public class GigFactory {
    public static Gig createGig(Long gigId, String title, String venue, LocalDateTime eventDateTime, DJ dj) {
        // Validate inputs. While the Helper class doesn't have specific methods for title or venue,
        // we can use the isNullOrEmpty method to ensure they are not empty.
        if (Helper.isNullOrEmpty(title)) {
            throw new IllegalArgumentException("Title cannot be null or empty.");
        }
        if (Helper.isNullOrEmpty(venue)) {
            throw new IllegalArgumentException("Venue cannot be null or empty.");
        }
        if (eventDateTime == null) {
            throw new IllegalArgumentException("Event date and time cannot be null.");
        }
        if (dj == null) {
            throw new IllegalArgumentException("DJ cannot be null.");
        }

        // Use the Builder pattern to construct the Gig object
        return new Gig.Builder()
                .setGigId(gigId)
                .setTitle(title.trim())
                .setVenue(venue.trim())
                .setEventDateTime(eventDateTime)
                .setDj(dj)
                .build();
    }
}