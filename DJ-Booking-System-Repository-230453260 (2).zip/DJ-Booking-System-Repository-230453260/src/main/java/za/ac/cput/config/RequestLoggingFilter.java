package za.ac.cput.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Temporary diagnostic filter — logs request method and key headers for multipart debugging.
 * Remove once issue is resolved.
 */
@Component
public class RequestLoggingFilter extends HttpFilter {

    private final Logger logger = LoggerFactory.getLogger(RequestLoggingFilter.class);

    @Override
    protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            logger.debug("[REQ-LOG] {} {}", request.getMethod(), request.getRequestURI());
            String ct = request.getHeader("Content-Type");
            logger.debug("[REQ-LOG] Content-Type: {}", ct);
            String length = request.getHeader("Content-Length");
            logger.debug("[REQ-LOG] Content-Length: {}", length);
            // Log the presence/absence of multipart boundary if available
            if (ct != null && ct.contains("multipart/form-data")) {
                logger.debug("[REQ-LOG] multipart detected; header: {}", ct);
            }
        } catch (Exception ex) {
            logger.warn("[REQ-LOG] failed to log request headers", ex);
        }
        chain.doFilter(request, response);
    }
}
