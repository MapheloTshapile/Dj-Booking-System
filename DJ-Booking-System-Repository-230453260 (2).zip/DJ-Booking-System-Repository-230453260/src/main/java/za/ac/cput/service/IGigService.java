package za.ac.cput.service;

import za.ac.cput.domain.Gig;

import java.util.List;

public interface IGigService extends IService<Gig, Long> {
    List<Gig> getAll();
}