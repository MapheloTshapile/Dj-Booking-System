package za.ac.cput.domain;

public enum AvailabilityStatus {
    AVAILABLE,
    UNAVAILABLE
}
