package za.ac.cput.domain;

import jakarta.persistence.*;

@Entity
public class Equipment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long equipmentId;
    private String equipmentName;
    private String type;

    protected Equipment() {}

    private Equipment(Builder builder) {
        this.equipmentId = builder.equipmentId;
        this.equipmentName = builder.equipmentName;
        this.type = builder.type;
    }

    public Long getEquipmentId() { return equipmentId; }
    public String getEquipmentName() { return equipmentName; }
    public String getType() { return type; }

    @Override
    public String toString() {
        return "Equipment{" +
                "equipmentId=" + equipmentId +
                ", equipmentName='" + equipmentName + '\'' +
                ", type='" + type + '\'' +
                '}';
    }

    public static class Builder {
        private Long equipmentId;
        private String equipmentName;
        private String type;

        public Builder setEquipmentId(Long equipmentId) {
            this.equipmentId = equipmentId;
            return this;
        }

        public Builder setEquipmentName(String equipmentName) {
            this.equipmentName = equipmentName;
            return this;
        }

        public Builder setType(String type) {
            this.type = type;
            return this;
        }

        public Builder copy(Equipment e) {
            this.equipmentId = e.equipmentId;
            this.equipmentName = e.equipmentName;
            this.type = e.type;
            return this;
        }

        public Equipment build() {
            return new Equipment(this);
        }
    }
}
