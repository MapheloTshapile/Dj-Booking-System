package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Review;
import za.ac.cput.repository.ReviewRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ReviewService implements IReviewService {

    private final ReviewRepository repository;

    @Autowired
    public ReviewService(ReviewRepository repository) {
        this.repository = repository;
    }

    @Override
    public Review create(Review review) {
        return repository.save(review);
    }

    @Override
    public Review read(Long reviewId) {
        Optional<Review> optionalReview = repository.findById(reviewId);
        return optionalReview.orElse(null);
    }

    @Override
    public Review update(Review review) {
        if (repository.existsById(review.getReviewId())) {
            return repository.save(review);
        }
        return null;
    }

    @Override
    public boolean delete(Long reviewId) {
        if (repository.existsById(reviewId)) {
            repository.deleteById(reviewId);
            return true;
        }
        return false;
    }

    @Override
    public List<Review> getAll() {
        return repository.findAll();
    }
}
